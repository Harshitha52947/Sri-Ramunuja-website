#!/usr/bin/env bash
set -e
if [ -z "$1" ]; then
  echo "Usage: ./push_to_github.sh <git-https-repo-url>"
  echo "Example: ./push_to_github.sh https://github.com/your-username/your-repo.git"
  exit 1
fi
REPO_URL="$1"
git init
git add .
git commit -m "Initial commit: storefront prototype" || true
git branch -M main
git remote add origin "$REPO_URL" || git remote set-url origin "$REPO_URL"
echo "Pushing to $REPO_URL (you may be prompted for credentials)..."
git push -u origin main
echo "Done. If this is a new repo, enable GitHub Pages from the repo Settings → Pages to publish the site."
