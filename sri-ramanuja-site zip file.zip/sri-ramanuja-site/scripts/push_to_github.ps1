param(
  [Parameter(Mandatory=$true)]
  [string]$RepoUrl
)
try {
  git init
  git add .
  git commit -m "Initial commit: storefront prototype" -ErrorAction SilentlyContinue
  git branch -M main
  git remote add origin $RepoUrl -ErrorAction SilentlyContinue
  git remote set-url origin $RepoUrl
  Write-Host "Pushing to $RepoUrl (you may be prompted for credentials)..."
  git push -u origin main
  Write-Host "Done. Enable GitHub Pages in repo Settings → Pages to publish the site."
} catch {
  Write-Error "Error: $_"
}
