Project: Sri Ramanuja Sarees & Dresses
===================================

Overview
--------
This is a small client-side storefront prototype built with static HTML, CSS and vanilla JavaScript. It includes:

- Owner dashboard (upload products with size variants, view orders, view products)
- Buyer flows (register/login, browse shop, select sizes (checkboxes), add to cart, checkout with COD)
- Local data persistence using `localStorage` (products, buyers, orders)
- Image uploads stored as Data URLs for demo persistence

Quick local run
--------------
Requirements: Python 3 (for local static server) or any static file server.

1. Start a local server from the project root:

```powershell
cd C:\workspace\sri-ramanuja-site
python -m http.server 8000
```

2. Open the dashboard in your browser:

http://localhost:8000/dashboard.html

Owner default credentials
-------------------------
- Username: `owner`
- Password: `owner123`

Owner actions
-------------
- Login as owner, use the Upload Product tab to add new products.
- Use the "Preset Sizes" panel to quickly add multiple sizes (S..XXXL) with cost and quantity.
- View orders and products from the Owner dashboard tabs.

Buyer actions
-------------
- Register as a buyer, login, browse the Shop tab.
- Sizes are presented as checkboxes so you can select multiple sizes and click "Add Selected to Cart".
- Proceed to Cart → Place Order (COD only). After placing order the My Orders tab should show the order.

Developer notes
---------------
- Data keys in localStorage:
  - `sri-ramanuja-owner` — owner credentials
  - `sri-ramanuja-buyers` — buyers map
  - `sri-ramanuja-products` — products array
  - `sri-ramanuja-orders` — orders array

Testing checklist
-----------------
- Upload a product with multiple sizes and quantities.
- Register and login as buyer, select multiple sizes, add to cart and place an order.
- Verify orders appear in the Owner dashboard and My Orders for the buyer.
- Verify quantities decrement and out-of-stock sizes are disabled.

Deploy to GitHub
----------------
You have two options: I can prepare the repo locally and give you commands to push, or (with your explicit instructions and credentials) I can push for you.

Manual push (recommended)

1. Create a new repository on GitHub (via the web UI) named e.g. `sri-ramanuja-site`.
2. From the project folder run:

```bash
git init
git add .
git commit -m "Initial commit: storefront prototype"
git branch -M main
git remote add origin https://github.com/<your-username>/<repo>.git
git push -u origin main
```

If you prefer to authenticate with a personal access token (PAT) when pushing via HTTPS, create a token with `repo` permissions and either use a credential helper or include it in the remote temporarily (not recommended to store token in plain text):

```bash
git remote set-url origin https://<TOKEN>@github.com/<your-username>/<repo>.git
git push -u origin main
# then remove token from remote
git remote set-url origin https://github.com/<your-username>/<repo>.git
```

Publish via GitHub Pages (static hosting)
---------------------------------------
1. In your GitHub repo, go to Settings → Pages.
2. Under Source, select branch `main` and folder `/ (root)` and Save.
3. The site will be available at `https://<your-username>.github.io/<repo>/` after a few minutes.

Automated helper scripts
------------------------
There are two helper scripts in the `scripts/` folder to assist pushing the repo to a Git remote. They only run local git commands and will prompt you for credentials if required.

- `scripts/push_to_github.sh` — Bash script for macOS/Linux
- `scripts/push_to_github.ps1` — PowerShell script for Windows

How I can help next
-------------------
- If you want I can attempt to push the repository to GitHub for you — give me the repository HTTPS URL (e.g. `https://github.com/your-username/your-repo.git`).
- I cannot accept secrets here; if you prefer automated push, either run one of the helper scripts locally or supply an HTTPS repo URL and confirm you will authenticate with your Git client.

If you'd like me to create the remote repo on your GitHub account and push automatically, provide a GitHub personal access token (PAT) with `repo` scope. For security, do NOT paste tokens into chat — instead run the helper script locally or let me guide you.

Files added for deployment help
-----------------------------
- `INSTRUCTIONS.md` (this file)
- `scripts/push_to_github.sh`
- `scripts/push_to_github.ps1`

Contact / Next steps
--------------------
Tell me whether you want me to push the repo for you (I will need the repo URL), or whether you'd prefer to run the script locally — I can provide the exact command to run.

*** End of instructions ***
# User Instructions

## Instructions provided so far

1. Add different categories for children, elders, dresses, sarees, home necessities, accessories, etc.
2. Include a search button to search for specific items.
3. Add filters and a wishlist bar.
4. Add an add-to-cart feature and ordering through the website, not only WhatsApp.
5. Add product ordering capabilities and a checkout/order form.
6. Add profile section and top category navigation bar.
7. Add product sizes.
8. Remove unnecessary tabs: BEAUTY, GENZ, STUDIO.
9. Use only dresses images for product listings.
10. Add mobile number or email in address/order form.
11. Remove “20 years” wherever present.
12. Add full address: Pincode 516434, Jammalamadugu, Kadapa (D), Andhra Pradesh.
13. Add Instagram and WhatsApp group links:
    - https://www.instagram.com/sriramanuja?igsh=NTVqamQwNTI4NGhw
    - https://chat.whatsapp.com/KZbi3YCKfHT3YFfuFrifop
14. Set cost of all products to ₹999.
15. Sync preview page with the main index page so both show the same content.

## Future instructions

- Add any new instructions below this section.
- The assistant will keep this file updated with future requirements as they are provided.

## Notes

- The main working file is `index.html`.
- Product data and images are managed in `assets/script.js`.
- Style changes are in `assets/styles.css`.
- The preview file `preview-inline.html` has been synced with the main storefront.
