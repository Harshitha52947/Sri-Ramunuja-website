Sri Ramanuja Sarees & Dresses - Local static prototype

Files:
- index.html : main page
- assets/styles.css : styles
- assets/script.js : product rendering
- assets/images/* : placeholder images

To preview locally:
- Open `index.html` in a browser (double-click) OR
- Run a local static server in the project folder, for example (PowerShell):
  python -m http.server 8000
  # then open http://localhost:8000

Replace placeholder images in `assets/images/` with your photos using the same filenames or update `assets/script.js` to point to real image paths.