const products = [
  { sku: 'NEW001', title: 'Pink Block Print Dress', category: 'Dresses', price: 1500, sizes: ['S','M','L'], img: 'https://images.unsplash.com/photo-1595777707802-4b12f1df97d6?auto=format&fit=crop&w=800&q=80' },
  { sku: 'NEW002', title: 'Grey Embroidered Dress', category: 'Dresses', price: 1500, sizes: ['S','M','L'], img: 'https://images.unsplash.com/photo-1612336307429-8a88e8d08dbb?auto=format&fit=crop&w=800&q=80' },
  { sku: 'NEW003', title: 'Green Floral Dress', category: 'Dresses', price: 900, sizes: ['S','M','L'], img: 'https://images.unsplash.com/photo-1595696602827-8f36ce7514f0?auto=format&fit=crop&w=800&q=80' },
  { sku: 'NEW004', title: 'Blue Cotton Dress', category: 'Dresses', price: 900, sizes: ['S','M','L'], img: 'https://images.unsplash.com/photo-1612528443702-f6741f3a6f1f?auto=format&fit=crop&w=800&q=80' }
];

const OWNER_CREDENTIALS = { username: 'owner', password: 'owner123' };
const OWNER_SESSION_KEY = 'sri-ramanuja-owner-session';
const CUSTOM_PRODUCT_STORAGE_KEY = 'sri-ramanuja-custom-products';
const ORDERS_STORAGE_KEY = 'sri-ramanuja-orders';

const categories = ['All', 'Dresses'];

function getSavedProducts() {
  try {
    return JSON.parse(localStorage.getItem(CUSTOM_PRODUCT_STORAGE_KEY) || '[]');
  } catch (error) {
    return [];
  }
}

function saveCustomProducts(productList) {
  localStorage.setItem(CUSTOM_PRODUCT_STORAGE_KEY, JSON.stringify(productList));
}

function loadCustomProducts() {
  const saved = getSavedProducts();
  if (!saved.length) return;
  saved.forEach(item => {
    products.push(item);
    if (!categories.includes(item.category)) categories.push(item.category);
  });
}

function addCustomProduct(product) {
  products.push(product);
  const current = getSavedProducts();
  current.push(product);
  saveCustomProducts(current);
}

function createProductFromUpload(title, category, price, imageUrl) {
  return {
    sku: `USER${Date.now()}`,
    title,
    category,
    price: Number(price) || 999,
    sizes: ['S','M','L'],
    img: imageUrl
  };
}

let filteredProducts = [...products];
const wishlist = new Map();
const cart = new Map();

function formatCurrency(value) {
  return `₹${value.toLocaleString('en-IN')}`;
}

function renderProducts() {
  const grid = document.getElementById('product-grid');
  if (!filteredProducts.length) {
    grid.innerHTML = '<p>No matching items found. Try a different search or filter.</p>';
    return;
  }

  grid.innerHTML = filteredProducts.map(p => {
    const sizeOptions = p.sizes.map(size => `<option value="${size}">${size}</option>`).join('');
    return `
      <div class="card">
        <img class="img-clickable" src="${p.img}" alt="${p.title}" onclick="openImageZoom('${p.img}','${p.title}')">
        <h5>${p.title}</h5>
        <div class="price">${formatCurrency(p.price)}</div>
        <div class="size-row">
          <label>Size
            <select id="size-${p.sku}">${sizeOptions}</select>
          </label>
        </div>
        <div class="card-actions">
          <button class="btn" type="button" onclick="addToWishlist('${p.sku}')">Wishlist</button>
          <button class="btn" type="button" onclick="addToCart('${p.sku}')">Add to Cart</button>
        </div>
      </div>
    `;
  }).join('');
}

function renderCategories() {
  const strip = document.getElementById('category-strip');
  strip.innerHTML = categories.map(category => `
    <button class="category-chip ${category === 'All' ? 'active' : ''}" type="button" onclick="selectCategory('${category}')">${category}</button>
  `).join('');
}

function updateWishlistCount() {
  document.getElementById('wishlist-count').textContent = wishlist.size;
}

function updateCartCount() {
  document.getElementById('cart-count').textContent = cart.size;
}

function renderWishlist() {
  const list = document.getElementById('wishlist-items');
  const panel = document.getElementById('wishlist-panel');
  const items = Array.from(wishlist.values());
  list.innerHTML = items.length ? items.map(item => `
    <div class="list-item">
      <span>${item.title}</span>
      <button class="btn" type="button" onclick="removeFromWishlist('${item.sku}')">Remove</button>
    </div>
  `).join('') : '';
  panel.querySelector('.empty-msg').style.display = items.length ? 'none' : 'block';
}

function renderCart() {
  const list = document.getElementById('cart-items');
  const panel = document.getElementById('cart-panel');
  const items = Array.from(cart.values());
  list.innerHTML = items.length ? items.map(item => `
    <div class="list-item">
      <div>
        <strong>${item.title}</strong>
        <div>${formatCurrency(item.price)}</div>
      </div>
      <button class="btn" type="button" onclick="removeFromCart('${item.sku}')">Remove</button>
    </div>
  `).join('') : '';
  panel.querySelector('.empty-msg').style.display = items.length ? 'none' : 'block';
  renderOrderSummary();
}

function renderOrderSummary() {
  const container = document.getElementById('order-summary');
  const totalEl = document.getElementById('order-total');
  const items = Array.from(cart.values());
  if (!items.length) {
    container.innerHTML = '<p>No items in cart yet. Add items from the product list.</p>';
    totalEl.textContent = formatCurrency(0);
    return;
  }
  const total = items.reduce((sum, item) => sum + item.price, 0);
  container.innerHTML = items.map(item => `
    <div class="order-summary-item">
      <span>${item.title}</span>
      <strong>${formatCurrency(item.price)}</strong>
    </div>
  `).join('');
  totalEl.textContent = formatCurrency(total);
}

function addToWishlist(sku) {
  const product = products.find(item => item.sku === sku);
  if (!product) return;
  wishlist.set(sku, product);
  updateWishlistCount();
  renderWishlist();
}

function removeFromWishlist(sku) {
  wishlist.delete(sku);
  updateWishlistCount();
  renderWishlist();
}

function addToCart(sku) {
  const product = products.find(item => item.sku === sku);
  if (!product) return;
  cart.set(sku, product);
  updateCartCount();
  renderCart();
}

function removeFromCart(sku) {
  cart.delete(sku);
  updateCartCount();
  renderCart();
}

function selectCategory(category) {
  document.querySelectorAll('.category-chip').forEach(button => {
    button.classList.toggle('active', button.textContent === category);
  });
  applyFilters();
}

function applyFilters() {
  const searchTerm = document.getElementById('search-input').value.trim().toLowerCase();
  const priceFilter = document.getElementById('price-filter').value;
  const activeCategory = document.querySelector('.category-chip.active')?.textContent || 'All';
  filteredProducts = products.filter(item => {
    const matchCategory = activeCategory === 'All' || item.category === activeCategory;
    const matchSearch = !searchTerm || item.title.toLowerCase().includes(searchTerm) || item.category.toLowerCase().includes(searchTerm);
    const matchPrice = priceFilter === 'All' || (priceFilter === 'Under1000' && item.price < 1000) || (priceFilter === '1000-2999' && item.price >= 1000 && item.price <= 2999) || (priceFilter === '3000plus' && item.price >= 3000);
    return matchCategory && matchSearch && matchPrice;
  });
  renderProducts();
}

function handleSubmit(event) {
  event.preventDefault();
  const name = document.getElementById('customer-name').value.trim();
  const phone = document.getElementById('customer-phone').value.trim();
  const email = document.getElementById('customer-email').value.trim();
  const address = document.getElementById('customer-address').value.trim();
  const paymentMethod = document.getElementById('payment-method').value.trim();
  const status = document.getElementById('order-status');
  if (!name || !phone || !address) {
    status.textContent = 'Please complete all fields to submit your order.';
    return;
  }
  if (!cart.size) {
    status.textContent = 'Your cart is empty. Add items before submitting an order.';
    return;
  }
  const orderItems = Array.from(cart.values()).map(item => ({ title: item.title, price: item.price }));
  const totalAmount = orderItems.reduce((sum, item) => sum + item.price, 0);
  const order = {
    orderId: `ORD${Date.now()}`,
    customerName: name,
    customerPhone: phone,
    customerEmail: email,
    customerAddress: address,
    paymentMethod: paymentMethod,
    items: orderItems,
    totalAmount: totalAmount,
    orderDate: new Date().toLocaleString(),
    status: 'Pending'
  };
  saveOrder(order);
  status.textContent = `✓ Order #${order.orderId} placed successfully! We will contact you on ${phone} within 24 hours.`;
  event.target.reset();
  cart.clear();
  updateCartCount();
  renderCart();
}

function saveOrder(order) {
  try {
    const existing = JSON.parse(localStorage.getItem(ORDERS_STORAGE_KEY) || '[]');
    existing.push(order);
    localStorage.setItem(ORDERS_STORAGE_KEY, JSON.stringify(existing));
  } catch (error) {
    console.error('Error saving order:', error);
  }
}

function getOrders() {
  try {
    return JSON.parse(localStorage.getItem(ORDERS_STORAGE_KEY) || '[]');
  } catch (error) {
    return [];
  }
}

function renderOrders() {
  const container = document.getElementById('orders-dashboard');
  if (!container) return;
  const orders = getOrders();
  if (!orders.length) {
    container.innerHTML = '<p style="grid-column:1/-1;color:#666">No orders yet.</p>';
    return;
  }
  container.innerHTML = orders.map(order => `
    <div class="order-item">
      <div><strong>#${order.orderId}</strong></div>
      <div>${order.customerName}</div>
      <div>${order.customerPhone}</div>
      <div>${order.orderDate}</div>
      <div>₹${order.totalAmount.toLocaleString('en-IN')}</div>
      <div><span class="order-status pending">${order.status}</span></div>
      <button class="btn small" onclick="viewOrderDetails('${order.orderId}')">View</button>
    </div>
  `).join('');
}

function viewOrderDetails(orderId) {
  const orders = getOrders();
  const order = orders.find(o => o.orderId === orderId);
  if (!order) return;
  const details = `
Order ID: ${order.orderId}
Customer: ${order.customerName}
Phone: ${order.customerPhone}
Email: ${order.customerEmail}
Address: ${order.customerAddress}
Payment: ${order.paymentMethod}
Date: ${order.orderDate}
Status: ${order.status}

Items:
${order.items.map(item => `- ${item.title}: ₹${item.price}`).join('\n')}

Total: ₹${order.totalAmount.toLocaleString('en-IN')}
  `;
  alert(details);
}

function openImageZoom(url, title) {
  const overlay = document.getElementById('image-modal');
  const modalImage = document.getElementById('modal-image');
  const modalTitle = document.getElementById('modal-title');
  modalImage.src = url;
  modalTitle.textContent = title;
  overlay.classList.add('active');
  document.body.style.overflow = 'hidden';
}

function closeImageZoom(event) {
  if (event.target.id === 'image-modal' || event.target.classList.contains('modal-close')) {
    const overlay = document.getElementById('image-modal');
    overlay.classList.remove('active');
    document.body.style.overflow = '';
  }
}

function isOwnerLoggedIn() {
  return sessionStorage.getItem(OWNER_SESSION_KEY) === 'true';
}

function setOwnerLoginStatus(status) {
  if (status) {
    sessionStorage.setItem(OWNER_SESSION_KEY, 'true');
  } else {
    sessionStorage.removeItem(OWNER_SESSION_KEY);
  }
}

function toggleAdminPanel() {
  const panel = document.querySelector('.admin-panel');
  const dashboard = document.getElementById('orders-section');
  const button = document.getElementById('login-btn');
  if (!panel) return;
  if (isOwnerLoggedIn()) {
    panel.style.display = 'block';
    if (dashboard) dashboard.style.display = 'block';
    button.textContent = 'Logout';
    document.getElementById('user-greeting').textContent = 'Hello, Owner';
    renderOrders();
  } else {
    panel.style.display = 'none';
    if (dashboard) dashboard.style.display = 'none';
    button.textContent = 'Owner Login';
    document.getElementById('user-greeting').textContent = 'Hello, Guest';
  }
}

function openOwnerLogin() {
  if (isOwnerLoggedIn()) {
    setOwnerLoginStatus(false);
    toggleAdminPanel();
  } else {
    const modal = document.getElementById('login-modal');
    modal.classList.add('active');
    document.body.style.overflow = 'hidden';
  }
}

function closeOwnerLogin(event) {
  if (event.target.id === 'login-modal' || event.target.classList.contains('modal-close')) {
    const modal = document.getElementById('login-modal');
    modal.classList.remove('active');
    document.body.style.overflow = '';
  }
}

function handleOwnerLogin(event) {
  event.preventDefault();
  const username = document.getElementById('owner-username').value.trim();
  const password = document.getElementById('owner-password').value.trim();
  const errorEl = document.getElementById('login-error');
  if (username === OWNER_CREDENTIALS.username && password === OWNER_CREDENTIALS.password) {
    setOwnerLoginStatus(true);
    toggleAdminPanel();
    document.getElementById('owner-login-form').reset();
    closeOwnerLogin({target: {id: 'login-modal'}});
    errorEl.textContent = '';
  } else {
    errorEl.textContent = 'Invalid username or password.';
  }
}

function updateUploadPreview() {
  const preview = document.getElementById('upload-image-preview');
  const file = document.getElementById('product-image-input').files[0];
  if (!file) {
    preview.innerHTML = 'Select an image to preview it here.';
    return;
  }
  const reader = new FileReader();
  reader.onload = () => {
    preview.innerHTML = `<img src="${reader.result}" alt="Upload preview">`;
  };
  reader.readAsDataURL(file);
}

function resetUploadForm() {
  document.getElementById('upload-form').reset();
  document.getElementById('upload-image-preview').innerHTML = 'Select an image to preview it here.';
}

function handleUploadForm(event) {
  event.preventDefault();
  const imageInput = document.getElementById('product-image-input');
  const title = document.getElementById('product-title').value.trim();
  const category = document.getElementById('product-category').value.trim() || 'Dresses';
  const price = document.getElementById('product-price').value.trim();
  const status = document.getElementById('upload-status');
  if (!imageInput.files.length || !title || !price) {
    status.textContent = 'Please select an image and fill title and price.';
    return;
  }
  const file = imageInput.files[0];
  const reader = new FileReader();
  reader.onload = () => {
    const product = createProductFromUpload(title, category, price, reader.result);
    addCustomProduct(product);
    renderCategories();
    applyFilters();
    resetUploadForm();
    status.textContent = 'Product uploaded successfully and added to the shop.';
  };
  reader.readAsDataURL(file);
}

function init() {
  loadCustomProducts();
  toggleAdminPanel();
  renderCategories();
  renderProducts();
  updateWishlistCount();
  updateCartCount();
  renderWishlist();
  renderCart();
  document.getElementById('search-btn').addEventListener('click', applyFilters);
  document.getElementById('search-input').addEventListener('keydown', event => {
    if (event.key === 'Enter') {
      event.preventDefault();
      applyFilters();
    }
  });
  document.getElementById('price-filter').addEventListener('change', applyFilters);
  document.getElementById('checkout-form').addEventListener('submit', handleSubmit);
  document.getElementById('upload-form').addEventListener('submit', handleUploadForm);
  document.getElementById('product-image-input').addEventListener('change', updateUploadPreview);
  resetUploadForm();
}

window.addEventListener('DOMContentLoaded', init);
