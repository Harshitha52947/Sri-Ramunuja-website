let currentUserType = null;
let currentUserEmail = null;
let cartItems = [];
let sizeVariantCount = 0;
let forgotPasswordUserType = null;

// Initialize
window.addEventListener('DOMContentLoaded', () => {
  const user = getCurrentUser();
  if (user) {
    currentUserType = user.type;
    currentUserEmail = user.email || user.username;
    if (user.type === 'owner') {
      showOwnerDashboard();
    } else {
      showBuyerDashboard();
    }
  } else {
    showLoginPage();
  }
});

// Login Tab Switching
function switchLoginTab(type) {
  document.querySelectorAll('.login-tab').forEach(btn => btn.classList.remove('active'));
  event.target.classList.add('active');
  document.querySelectorAll('.login-form').forEach(form => form.style.display = 'none');
  if (type === 'owner') {
    document.getElementById('owner-login-form').style.display = 'block';
  } else if (type === 'buyer') {
    document.getElementById('buyer-login-form').style.display = 'block';
  }
}

function switchToBuyerRegister() {
  document.getElementById('buyer-login-form').style.display = 'none';
  document.getElementById('buyer-register-form').style.display = 'block';
}

function switchToBuyerLogin() {
  document.getElementById('buyer-register-form').style.display = 'none';
  document.getElementById('buyer-login-form').style.display = 'block';
}

// Login Handlers
function handleOwnerLogin(event) {
  event.preventDefault();
  const username = document.getElementById('owner-username').value.trim();
  const password = document.getElementById('owner-password').value.trim();
  const result = loginOwner(username, password);
  if (result.success) {
    showOwnerDashboard();
  } else {
    document.getElementById('owner-login-error').textContent = result.error;
  }
}

function handleBuyerLogin(event) {
  event.preventDefault();
  const email = document.getElementById('buyer-email').value.trim();
  const password = document.getElementById('buyer-password').value.trim();
  const result = loginBuyer(email, password);
  if (result.success) {
    currentUserEmail = email;
    showBuyerDashboard();
  } else {
    document.getElementById('buyer-login-error').textContent = result.error;
  }
}

function handleBuyerRegister(event) {
  event.preventDefault();
  const name = document.getElementById('buyer-reg-name').value.trim();
  const email = document.getElementById('buyer-reg-email').value.trim();
  const phone = document.getElementById('buyer-reg-phone').value.trim();
  const password = document.getElementById('buyer-reg-password').value.trim();
  const result = registerBuyer(name, email, phone, password);
  if (result.success) {
    alert('Registration successful! Please login.');
    switchToBuyerLogin();
    document.getElementById('buyer-email').value = email;
  } else {
    document.getElementById('buyer-register-error').textContent = result.error;
  }
}

// Password Management
function showOwnerForgotPassword() {
  forgotPasswordUserType = 'owner';
  document.getElementById('forgot-password-message').textContent = 'Enter your email and new password';
  document.getElementById('forgot-password-modal').style.display = 'flex';
}

function showBuyerForgotPassword() {
  forgotPasswordUserType = 'buyer';
  document.getElementById('forgot-password-message').textContent = 'Enter your email and new password';
  document.getElementById('forgot-password-modal').style.display = 'flex';
}

function closeForgotPassword(event) {
  if (event.target.id === 'forgot-password-modal' || event.target.classList.contains('modal-close')) {
    document.getElementById('forgot-password-modal').style.display = 'none';
  }
}

function resetPassword() {
  const email = document.getElementById('forgot-email').value.trim();
  const newPassword = document.getElementById('forgot-new-password').value.trim();
  const errorEl = document.getElementById('forgot-password-error');
  if (!email || !newPassword) {
    errorEl.textContent = 'Please fill all fields';
    return;
  }
  const result = resetBuyerPassword(email, newPassword);
  if (result.success) {
    alert('Password reset successfully!');
    closeForgotPassword({target: {id: 'forgot-password-modal'}});
  } else {
    errorEl.textContent = result.error;
  }
}

function showChangePasswordModal(type) {
  currentUserType = type;
  document.getElementById('change-password-modal').style.display = 'flex';
}

function closeChangePasswordModal(event) {
  if (event.target.id === 'change-password-modal' || event.target.classList.contains('modal-close')) {
    document.getElementById('change-password-modal').style.display = 'none';
  }
}

function handleChangePassword(event) {
  event.preventDefault();
  const oldPassword = document.getElementById('old-password').value.trim();
  const newPassword = document.getElementById('new-password').value.trim();
  const errorEl = document.getElementById('change-password-error');
  let result;
  if (currentUserType === 'owner') {
    const owner = JSON.parse(localStorage.getItem('sri-ramanuja-owner'));
    result = changeOwnerPassword(owner.username, oldPassword, newPassword);
  } else {
    result = changeBuyerPassword(currentUserEmail, oldPassword, newPassword);
  }
  if (result.success) {
    alert('Password changed successfully!');
    closeChangePasswordModal({target: {id: 'change-password-modal'}});
    event.target.reset();
  } else {
    errorEl.textContent = result.error;
  }
}

// Page Display
function showLoginPage() {
  document.getElementById('login-page').style.display = 'block';
  document.getElementById('owner-dashboard').style.display = 'none';
  document.getElementById('buyer-dashboard').style.display = 'none';
}

function showOwnerDashboard() {
  document.getElementById('login-page').style.display = 'none';
  document.getElementById('owner-dashboard').style.display = 'block';
  document.getElementById('buyer-dashboard').style.display = 'none';
  renderOwnerOrders();
}

function showBuyerDashboard() {
  const user = getCurrentUser();
  document.getElementById('buyer-greeting').textContent = `Welcome, ${user.name}`;
  document.getElementById('login-page').style.display = 'none';
  document.getElementById('owner-dashboard').style.display = 'none';
  document.getElementById('buyer-dashboard').style.display = 'block';
  renderProducts();
  renderBuyerOrders();
}

// Owner Product Upload
function addSizeVariant() {
  sizeVariantCount++;
  const container = document.getElementById('size-variants');
  const variantHtml = `
    <div id="variant-${sizeVariantCount}" style="display:flex;gap:10px;margin-bottom:10px;align-items:center">
      <select class="size-input" required>
        <option value="S">S</option>
        <option value="M">M</option>
        <option value="L">L</option>
        <option value="XL">XL</option>
        <option value="XXL">XXL</option>
        <option value="XXXL">XXXL</option>
      </select>
      <input type="number" placeholder="Cost" class="cost-input" min="0" required />
      <input type="number" placeholder="Quantity" class="qty-input" min="0" value="1" required style="width:100px" />
      <button type="button" class="btn small" onclick="removeSizeVariant(${sizeVariantCount})">Remove</button>
    </div>
  `;
  container.insertAdjacentHTML('beforeend', variantHtml);
}

function removeSizeVariant(id) {
  document.getElementById(`variant-${id}`)?.remove();
}

document.addEventListener('change', (e) => {
  if (e.target.id === 'product-image') {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      document.getElementById('product-preview').innerHTML = `<img src="${reader.result}" style="max-width:100%;max-height:200px;border-radius:8px" />`;
    };
    reader.readAsDataURL(file);
  }
});

function handleProductUpload(event) {
  event.preventDefault();
  const title = document.getElementById('product-title').value.trim();
  const category = document.getElementById('product-category').value;
  const image = document.getElementById('product-image').files[0];
  const messageEl = document.getElementById('upload-message');
  if (!title || !category || !image) {
    messageEl.textContent = 'Please fill all fields';
    messageEl.style.color = 'red';
    return;
  }
  const sizeInputs = document.querySelectorAll('.size-input');
  const costInputs = document.querySelectorAll('.cost-input');
  const qtyInputs = document.querySelectorAll('.qty-input');
  if (sizeInputs.length === 0) {
    messageEl.textContent = 'Please add at least one size variant';
    messageEl.style.color = 'red';
    return;
  }
  const sizeVariants = Array.from(sizeInputs).map((input, idx) => ({
    size: input.value.trim(),
    cost: Number(costInputs[idx].value),
    qty: Number(qtyInputs[idx].value) || 0
  }));
  const basePrice = Math.min(...sizeVariants.map(s => s.cost));
  const form = event.target;
  const reader = new FileReader();
  reader.onload = () => {
    addProduct(title, category, basePrice, reader.result, sizeVariants);
    messageEl.textContent = '✓ Product uploaded successfully!';
    messageEl.style.color = 'green';
    form.reset();
    document.getElementById('product-preview').textContent = 'Select image to preview';
    document.getElementById('size-variants').innerHTML = '';
    sizeVariantCount = 0;
  };
  reader.readAsDataURL(image);
}

function togglePresetSizes() {
  const el = document.getElementById('preset-sizes-container');
  if (!el) return;
  el.style.display = el.style.display === 'none' ? 'block' : 'none';
}

function applyPresetSizes() {
  const checked = Array.from(document.querySelectorAll('input[name="preset-size"]:checked')).map(i => i.value);
  const cost = Number(document.getElementById('preset-cost').value) || 0;
  const qty = Number(document.getElementById('preset-qty').value) || 0;
  if (!checked.length) return alert('Select sizes to apply');
  if (!cost) return alert('Enter cost for selected sizes');
  checked.forEach(sz => {
    addSizeVariant();
    // set last variant inputs
    const last = document.querySelector('#size-variants > div:last-child');
    if (!last) return;
    const sel = last.querySelector('.size-input');
    const costInput = last.querySelector('.cost-input');
    const qtyInput = last.querySelector('.qty-input');
    if (sel) sel.value = sz;
    if (costInput) costInput.value = cost;
    if (qtyInput) qtyInput.value = qty;
  });
  // hide preset area
  togglePresetSizes();
}

// Owner Orders Tab
function switchOwnerTab(tab) {
  document.querySelectorAll('.dashboard-tab').forEach(t => t.style.display = 'none');
  document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
  document.getElementById(`${tab}-tab`).style.display = 'block';
  try { event.target.classList.add('active'); } catch(e) {}
  if (tab === 'orders') renderOwnerOrders();
  if (tab === 'products') renderOwnerProducts();
}

function renderOwnerProducts() {
  const products = getAllProducts();
  const container = document.getElementById('owner-products-list');
  if (!container) return;
  if (!products.length) {
    container.innerHTML = '<p>No products yet</p>';
    return;
  }
  const html = products.map(p => {
    const sizes = p.sizeVariants.map(v => `${v.size} (₹${v.cost} x ${v.qty ?? '∞'})`).join(', ');
    const outOfStock = p.sizeVariants.every(v => typeof v.qty === 'number' && v.qty <= 0);
    return `
      <div style="padding:12px;border:1px solid #ddd;border-radius:8px;margin-bottom:10px;background:#fff;display:flex;justify-content:space-between;align-items:center">
        <div>
          <strong>${p.title}</strong><br>
          <small>Category: ${p.category}</small><br>
          <small>Sizes: ${sizes}</small>
        </div>
        <div style="text-align:right">
          <div style="margin-bottom:8px">${outOfStock ? '<span style="color:#c00;font-weight:700">Out of stock</span>' : '<span style="color:#0a0">In stock</span>'}</div>
          <button class="btn small" onclick="removeProduct('${p.sku}')">Remove</button>
        </div>
      </div>
    `;
  }).join('');
  container.innerHTML = html;
}

function removeProduct(sku) {
  const products = getAllProducts();
  const remaining = products.filter(p => p.sku !== sku);
  localStorage.setItem('sri-ramanuja-products', JSON.stringify(remaining));
  renderOwnerProducts();
}

function renderOwnerOrders() {
  const orders = getAllOrders();
  const container = document.getElementById('owner-orders-list');
  if (!orders.length) {
    container.innerHTML = '<p>No orders yet</p>';
    return;
  }
  const html = `
    <table style="width:100%;border-collapse:collapse">
      <tr style="background:#f0f0f0;font-weight:bold;border-bottom:2px solid #ddd">
        <td style="padding:10px;border-right:1px solid #ddd">Order ID</td>
        <td style="padding:10px;border-right:1px solid #ddd">Customer</td>
        <td style="padding:10px;border-right:1px solid #ddd">Phone</td>
        <td style="padding:10px;border-right:1px solid #ddd">Amount</td>
        <td style="padding:10px;border-right:1px solid #ddd">Date</td>
        <td style="padding:10px;border-right:1px solid #ddd">Status</td>
        <td style="padding:10px">Action</td>
      </tr>
      ${orders.map(o => `
        <tr style="border-bottom:1px solid #ddd">
          <td style="padding:10px;border-right:1px solid #ddd">${o.orderId}</td>
          <td style="padding:10px;border-right:1px solid #ddd">${o.customerName}</td>
          <td style="padding:10px;border-right:1px solid #ddd">${o.customerPhone}</td>
          <td style="padding:10px;border-right:1px solid #ddd">₹${o.totalAmount}</td>
          <td style="padding:10px;border-right:1px solid #ddd">${o.orderDate}</td>
          <td style="padding:10px;border-right:1px solid #ddd">
            <select onchange="updateOrderStatus('${o.orderId}', this.value)" style="padding:5px">
              <option value="Pending" ${o.status === 'Pending' ? 'selected' : ''}>Pending</option>
              <option value="Confirmed" ${o.status === 'Confirmed' ? 'selected' : ''}>Confirmed</option>
              <option value="Shipped" ${o.status === 'Shipped' ? 'selected' : ''}>Shipped</option>
              <option value="Delivered" ${o.status === 'Delivered' ? 'selected' : ''}>Delivered</option>
            </select>
          </td>
          <td style="padding:10px"><button class="btn small" onclick="viewOrderDetails('${o.orderId}')">View</button></td>
        </tr>
      `).join('')}
    </table>
  `;
  container.innerHTML = html;
}

function viewOrderDetails(orderId) {
  const orders = getAllOrders();
  const order = orders.find(o => o.orderId === orderId);
  if (!order) return;
  const items = order.items.map(i => `- ${i.title} (${i.size}): ₹${i.cost}`).join('\n');
  alert(`Order #${order.orderId}\nCustomer: ${order.customerName}\nPhone: ${order.customerPhone}\nEmail: ${order.customerEmail}\nAddress: ${order.address}\nItems:\n${items}\nTotal: ₹${order.totalAmount}\nStatus: ${order.status}`);
}

// Buyer Shop
function renderProducts() {
  const products = getAllProducts();
  const container = document.getElementById('products-grid');
  if (!products.length) {
    container.innerHTML = '<p>No products available</p>';
    return;
  }
  container.innerHTML = products.map(p => {
    const allOut = p.sizeVariants.every(v => typeof v.qty === 'number' && v.qty <= 0);
    const options = p.sizeVariants.map((v, idx) => {
      const disabled = (typeof v.qty === 'number' && v.qty <= 0) ? 'disabled' : '';
      const label = `${v.size} - ₹${v.cost}${disabled ? ' (Out)' : ''}`;
      return `<label style="display:inline-flex;align-items:center;margin-right:8px"><input type="checkbox" name="size-${p.sku}" value="${v.size}|${v.cost}" ${disabled} /> <span style="margin-left:6px">${label}</span></label>`;
    }).join('');
    return `
    <div class="product-card">
      <img src="${p.image}" alt="${p.title}" style="width:100%;height:200px;object-fit:cover;border-radius:8px" />
      <h4>${p.title}</h4>
      <p>Category: ${p.category}</p>
      <div>Sizes: ${options}</div>
      <div style="margin-top:8px">
        <button class="btn" onclick="addSelectedToCart('${p.sku}', '${p.title}')" ${allOut ? 'disabled' : ''}>${allOut ? 'Out of stock' : 'Add Selected to Cart'}</button>
      </div>
    </div>
  `;
  }).join('');
}

function addToCart(sku, title) {
  const sizeSelect = document.getElementById(`size-${sku}`);
  // Deprecated single-select path — prefer checkboxes. Try to fallback.
  const sel = document.getElementById(`size-${sku}`);
  if (!sel) return alert('Please use the checkboxes to select sizes and click "Add Selected to Cart"');
  const [size, cost] = sel.value.split('|');
  const products = getAllProducts();
  const prod = products.find(p => p.sku === sku);
  const variant = prod?.sizeVariants.find(v => v.size === size);
  if (variant && typeof variant.qty === 'number' && variant.qty <= 0) {
    return alert('Selected size is out of stock');
  }
  cartItems.push({ sku, title, size, cost: Number(cost) });
  alert('Added to cart!');
  renderCart();
}

function addSelectedToCart(sku, title) {
  const checked = Array.from(document.querySelectorAll(`input[name="size-${sku}"]:checked`));
  if (!checked.length) return alert('Please select one or more sizes');
  const products = getAllProducts();
  const prod = products.find(p => p.sku === sku);
  checked.forEach(ch => {
    const [size, cost] = ch.value.split('|');
    const variant = prod?.sizeVariants.find(v => v.size === size);
    if (variant && typeof variant.qty === 'number' && variant.qty <= 0) return; // skip out of stock
    cartItems.push({ sku, title, size, cost: Number(cost) });
  });
  alert('Selected sizes added to cart');
  renderCart();
}

function renderCart() {
  const container = document.getElementById('cart-items-list');
  const summaryEl = document.getElementById('cart-summary');
  if (!cartItems.length) {
    container.innerHTML = '<p>Your cart is empty</p>';
    summaryEl.style.display = 'none';
    return;
  }
  const total = cartItems.reduce((sum, item) => sum + item.cost, 0);
  container.innerHTML = `
    <table style="width:100%;border-collapse:collapse">
      <tr style="background:#f0f0f0;border-bottom:2px solid #ddd">
        <th style="padding:10px;text-align:left">Product</th>
        <th style="padding:10px;text-align:left">Size</th>
        <th style="padding:10px;text-align:left">Cost</th>
        <th style="padding:10px;text-align:left">Action</th>
      </tr>
      ${cartItems.map((item, idx) => `
        <tr style="border-bottom:1px solid #ddd">
          <td style="padding:10px">${item.title}</td>
          <td style="padding:10px">${item.size}</td>
          <td style="padding:10px">₹${item.cost}</td>
          <td style="padding:10px"><button class="btn small" onclick="removeFromCart(${idx})">Remove</button></td>
        </tr>
      `).join('')}
    </table>
  `;
  document.getElementById('cart-total').textContent = `₹${total.toLocaleString('en-IN')}`;
  summaryEl.style.display = 'block';
}

function removeFromCart(idx) {
  cartItems.splice(idx, 1);
  renderCart();
}

function searchProducts() {
  const query = document.getElementById('search-input').value.toLowerCase();
  const products = getAllProducts().filter(p => p.title.toLowerCase().includes(query) || p.category.toLowerCase().includes(query));
  const container = document.getElementById('products-grid');
  if (!products.length) {
    container.innerHTML = '<p>No products found</p>';
    return;
  }
  container.innerHTML = products.map(p => {
    const allOut = p.sizeVariants.every(v => typeof v.qty === 'number' && v.qty <= 0);
    const options = p.sizeVariants.map(v => {
      const disabled = (typeof v.qty === 'number' && v.qty <= 0) ? 'disabled' : '';
      const label = `${v.size} - ₹${v.cost}${disabled ? ' (Out)' : ''}`;
      return `<label style="display:inline-flex;align-items:center;margin-right:8px"><input type="checkbox" name="size-${p.sku}" value="${v.size}|${v.cost}" ${disabled} /> <span style="margin-left:6px">${label}</span></label>`;
    }).join('');
    return `
    <div class="product-card">
      <img src="${p.image}" alt="${p.title}" style="width:100%;height:200px;object-fit:cover;border-radius:8px" />
      <h4>${p.title}</h4>
      <p>Category: ${p.category}</p>
      <div>Sizes: ${options}</div>
      <div style="margin-top:8px">
        <button class="btn" onclick="addSelectedToCart('${p.sku}', '${p.title}')" ${allOut ? 'disabled' : ''}>${allOut ? 'Out of stock' : 'Add Selected to Cart'}</button>
      </div>
    </div>
  `;
  }).join('');
}

function submitOrder(event) {
  event.preventDefault();
  const address = document.getElementById('delivery-address').value.trim();
  const paymentMethod = document.getElementById('payment-method').value;
  if (!address || !paymentMethod || !cartItems.length) {
    document.getElementById('order-message').textContent = 'Please fill all fields and add items to cart';
    document.getElementById('order-message').style.color = 'red';
    return;
  }
  const totalAmount = cartItems.reduce((sum, item) => sum + item.cost, 0);
  // determine buyer email: prefer session, then currentUserEmail, then any email field
  const sessionUser = getCurrentUser();
  const buyerEmail = (sessionUser && sessionUser.type === 'buyer') ? sessionUser.email : (currentUserEmail || (document.getElementById('buyer-reg-email')?.value || document.getElementById('buyer-email')?.value || ''));
  if (!buyerEmail) {
    document.getElementById('order-message').textContent = 'You must be logged in as a buyer to place an order.';
    document.getElementById('order-message').style.color = 'red';
    return;
  }
  currentUserEmail = buyerEmail;
  // call app.js placeOrder to record and update stock
  const order = placeOrder(buyerEmail, cartItems, totalAmount, address, paymentMethod);
  if (order && order.orderId) {
    document.getElementById('order-message').textContent = `✓ Order ${order.orderId} placed successfully! You can track it in "My Orders"`;
    document.getElementById('order-message').style.color = 'green';
    cartItems = [];
    renderCart();
    event.target.reset();
    // refresh buyer orders view
    try { renderBuyerOrders(); } catch(e) {}
  } else {
    document.getElementById('order-message').textContent = 'Error placing order';
    document.getElementById('order-message').style.color = 'red';
  }
}

// Buyer Orders
function switchBuyerTab(tab) {
  document.querySelectorAll('#buyer-dashboard .dashboard-tab').forEach(t => t.style.display = 'none');
  document.querySelectorAll('#buyer-dashboard .tab-btn').forEach(b => b.classList.remove('active'));
  document.getElementById(`${tab}-tab`).style.display = 'block';
  event.target.classList.add('active');
  if (tab === 'orders') renderBuyerOrders();
  if (tab === 'shop') renderProducts();
  if (tab === 'cart') renderCart();
}

function renderBuyerOrders() {
  const orders = getOrdersByBuyer(currentUserEmail);
  const container = document.getElementById('buyer-orders-list');
  if (!orders.length) {
    container.innerHTML = '<p>You have no orders yet</p>';
    return;
  }
  const html = `
    <table style="width:100%;border-collapse:collapse">
      <tr style="background:#f0f0f0;font-weight:bold;border-bottom:2px solid #ddd">
        <td style="padding:10px;border-right:1px solid #ddd">Order ID</td>
        <td style="padding:10px;border-right:1px solid #ddd">Items</td>
        <td style="padding:10px;border-right:1px solid #ddd">Amount</td>
        <td style="padding:10px;border-right:1px solid #ddd">Date</td>
        <td style="padding:10px">Status</td>
      </tr>
      ${orders.map(o => `
        <tr style="border-bottom:1px solid #ddd">
          <td style="padding:10px;border-right:1px solid #ddd">${o.orderId}</td>
          <td style="padding:10px;border-right:1px solid #ddd">${o.items.length} item(s)</td>
          <td style="padding:10px;border-right:1px solid #ddd">₹${o.totalAmount}</td>
          <td style="padding:10px;border-right:1px solid #ddd">${o.orderDate}</td>
          <td style="padding:10px"><strong>${o.status}</strong></td>
        </tr>
      `).join('')}
    </table>
  `;
  container.innerHTML = html;
}
