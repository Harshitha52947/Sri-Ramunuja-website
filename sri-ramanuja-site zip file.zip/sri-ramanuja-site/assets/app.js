// Storage Keys
const OWNER_STORAGE_KEY = 'sri-ramanuja-owner';
const BUYER_STORAGE_KEY = 'sri-ramanuja-buyers';
const PRODUCTS_STORAGE_KEY = 'sri-ramanuja-products';
const ORDERS_STORAGE_KEY = 'sri-ramanuja-orders';
const SESSION_KEY = 'sri-ramanuja-session';

// Default Owner (can change password)
const DEFAULT_OWNER = { username: 'owner', password: 'owner123', email: 'owner@sriramanuja.com' };

// Initialize default owner
function initializeOwner() {
  if (!localStorage.getItem(OWNER_STORAGE_KEY)) {
    localStorage.setItem(OWNER_STORAGE_KEY, JSON.stringify(DEFAULT_OWNER));
  }
}

// Session Management
function getCurrentUser() {
  try {
    return JSON.parse(sessionStorage.getItem(SESSION_KEY)) || null;
  } catch {
    return null;
  }
}

function setCurrentUser(user) {
  sessionStorage.setItem(SESSION_KEY, JSON.stringify(user));
}

function logout() {
  sessionStorage.removeItem(SESSION_KEY);
  location.reload();
}

// Buyer Management
function registerBuyer(name, email, phone, password) {
  const buyers = JSON.parse(localStorage.getItem(BUYER_STORAGE_KEY) || '{}');
  if (buyers[email]) return { success: false, error: 'Email already registered' };
  buyers[email] = { name, email, phone, password, registeredDate: new Date().toLocaleString() };
  localStorage.setItem(BUYER_STORAGE_KEY, JSON.stringify(buyers));
  return { success: true };
}

function loginBuyer(email, password) {
  const buyers = JSON.parse(localStorage.getItem(BUYER_STORAGE_KEY) || '{}');
  const buyer = buyers[email];
  if (!buyer || buyer.password !== password) return { success: false, error: 'Invalid email or password' };
  setCurrentUser({ type: 'buyer', email, name: buyer.name, phone: buyer.phone });
  return { success: true };
}

function loginOwner(username, password) {
  const owner = JSON.parse(localStorage.getItem(OWNER_STORAGE_KEY));
  if (!owner || owner.username !== username || owner.password !== password) {
    return { success: false, error: 'Invalid credentials' };
  }
  setCurrentUser({ type: 'owner', username, email: owner.email });
  return { success: true };
}

function changeBuyerPassword(email, oldPassword, newPassword) {
  const buyers = JSON.parse(localStorage.getItem(BUYER_STORAGE_KEY) || '{}');
  const buyer = buyers[email];
  if (!buyer || buyer.password !== oldPassword) return { success: false, error: 'Old password incorrect' };
  buyer.password = newPassword;
  localStorage.setItem(BUYER_STORAGE_KEY, JSON.stringify(buyers));
  return { success: true };
}

function changeOwnerPassword(username, oldPassword, newPassword) {
  const owner = JSON.parse(localStorage.getItem(OWNER_STORAGE_KEY));
  if (!owner || owner.username !== username || owner.password !== oldPassword) {
    return { success: false, error: 'Old password incorrect' };
  }
  owner.password = newPassword;
  localStorage.setItem(OWNER_STORAGE_KEY, JSON.stringify(owner));
  return { success: true };
}

function resetBuyerPassword(email, newPassword) {
  const buyers = JSON.parse(localStorage.getItem(BUYER_STORAGE_KEY) || '{}');
  if (!buyers[email]) return { success: false, error: 'Email not found' };
  buyers[email].password = newPassword;
  localStorage.setItem(BUYER_STORAGE_KEY, JSON.stringify(buyers));
  return { success: true };
}

// Product Management with Variants (Size + Cost)
function addProduct(title, category, basePrice, image, sizeVariants) {
  const products = JSON.parse(localStorage.getItem(PRODUCTS_STORAGE_KEY) || '[]');
  const product = {
    sku: `SKU${Date.now()}`,
    title,
    category,
    basePrice,
    image,
    sizeVariants, // Array of {size, cost}
    uploadedBy: getCurrentUser().username || getCurrentUser().email,
    uploadDate: new Date().toLocaleString()
  };
  products.push(product);
  localStorage.setItem(PRODUCTS_STORAGE_KEY, JSON.stringify(products));
  return product;
}

function getAllProducts() {
  return JSON.parse(localStorage.getItem(PRODUCTS_STORAGE_KEY) || '[]');
}

// Order Management
function placeOrder(customerEmail, items, totalAmount, address, paymentMethod) {
  // decrement stock quantities for each ordered item and save updated products
  const products = JSON.parse(localStorage.getItem(PRODUCTS_STORAGE_KEY) || '[]');
  items.forEach(it => {
    const prod = products.find(p => p.sku === it.sku);
    if (prod && Array.isArray(prod.sizeVariants)) {
      const variant = prod.sizeVariants.find(v => v.size === it.size);
      if (variant) {
        // if quantity field exists, decrement; otherwise assume infinite stock
        if (typeof variant.qty === 'number') {
          variant.qty = Math.max(0, variant.qty - 1);
        }
      }
    }
  });
  localStorage.setItem(PRODUCTS_STORAGE_KEY, JSON.stringify(products));

  const orders = JSON.parse(localStorage.getItem(ORDERS_STORAGE_KEY) || '[]');
  const buyer = JSON.parse(localStorage.getItem(BUYER_STORAGE_KEY) || '{}')[customerEmail];
  const order = {
    orderId: `ORD${Date.now()}`,
    customerEmail,
    customerName: buyer?.name || 'Guest',
    customerPhone: buyer?.phone || '',
    items, // Array of {sku, title, size, cost}
    totalAmount,
    address,
    paymentMethod,
    orderDate: new Date().toLocaleString(),
    status: 'Pending'
  };
  orders.push(order);
  localStorage.setItem(ORDERS_STORAGE_KEY, JSON.stringify(orders));
  return order;
}

function getOrdersByBuyer(email) {
  const orders = JSON.parse(localStorage.getItem(ORDERS_STORAGE_KEY) || '[]');
  return orders.filter(o => o.customerEmail === email);
}

function getAllOrders() {
  return JSON.parse(localStorage.getItem(ORDERS_STORAGE_KEY) || '[]');
}

function updateOrderStatus(orderId, status) {
  const orders = JSON.parse(localStorage.getItem(ORDERS_STORAGE_KEY) || '[]');
  const order = orders.find(o => o.orderId === orderId);
  if (order) {
    order.status = status;
    localStorage.setItem(ORDERS_STORAGE_KEY, JSON.stringify(orders));
  }
}

// Initialize
initializeOwner();
